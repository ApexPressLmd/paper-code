# Implementation notes

The manuscript fixes the architecture, every numerical constant and the statistical procedures. The
points below are not stated in the manuscript; this file records how this code resolves each one, so
that a reader can see which behaviour comes from the paper and which from the implementation.

## Offline construction (Algorithm 1, implemented in the order of the algorithm)
1. **Passage splitting.** Documents are split on blank lines, then into passages of at most four sentences.
2. **Candidate conflicts** are found on the extracted surface names, compared after normalisation
   (case, punctuation, articles). This happens before structural unification, which comes last in
   Algorithm 1.
3. **KeepDropOrMerge.**
   - Facts that differ in time or scope are kept, with no model call.
   - The passage-level NLI contradiction score is computed and passed to the resolution agent as a review
     signal. It never removes a fact by itself.
   - A drop is applied only when the justification is source-based: it shares at least three content words
     with one of the two evidence passages and does not appeal to similarity.
   - A merge is applied only when the normalised triples are equal or the NLI model entails each fact from
     the other (≥ 0.5).
   - Anything else is kept and flagged uncertain.
4. **Schema.** A schema is a relation type; its frequency is the number of active facts that use it. If
   all frequencies are equal, so that none exceeds the P40 percentile, all schemas are kept.
5. **Structural unification** merges entity, type and passage nodes whose embedding similarity is
   ≥ 0.86 (union-find). An entity or type group is represented by its most frequent member; a passage group
   by its earliest passage. Merged passages and types resolve to the representative node.
6. **Indexing-graph directions.** Every fact, ontology and source-evidence edge is added in both
   directions with its bridge weight, so propagation can move from passages to entities and back.
7. **Concept pairs "observed in the ontology layer"** are pairs of active concepts that occur in the same
   document. The first-mention ranks i < j are first-appearance ranks in the corpus D (documents in corpus
   order, passages in reading order).
8. **Typed-relation direction** (`prerequisite_mining.typed_direction`): `X requires Y` and `X based_on Y`
   give the edge Y → X; `X precedes Y` gives X → Y. When two signals give the same ω, the more reliable one
   is stored as the edge source.
9. **Offline token limits.** Extraction uses 512 new tokens and conflict resolution 256
   (`decoding.offline_max_new_tokens`).
10. **Mining-signal ablations** (Supplementary Table S5) change the graph, so they are applied by
    `build_graph.py --variant=typed-only|cooc-only|order-only`. `run_inference.py` refuses them.

## Retrieval
11. **Sub-question cap.** Decomposition keeps at most four sub-questions, matching the four-hop limit.
12. **When the reasoning DAG is built.** Only for chained questions, so the classifier runs before
    retrieval. This keeps a parallel question at nine calls (Appendix B lists the DAG call as 0–1).
    Parallel sub-questions have no dependency edges and are ordered by foundationality alone.
13. **Concept identification.** Ontology concepts whose surface name occurs in the question or a
    sub-question; if none does, concepts whose content tokens are a subset of the text's tokens.
14. **Base-teleport mass.** Each of the top-30 facts adds its clipped cosine similarity to both endpoints
    and 0.5 × that similarity to its evidence passage; each of the top-30 passages adds its similarity.
15. **PageRank.** By default (`retrieval.ppr_engine: networkx`), `nx.pagerank` runs on the weighted
    MultiDiGraph. It uses damping 0.85 = 1 − α, personalization and dangling distributions both equal to
    t̃, and tolerance tol / N, because NetworkX stops when its L1 error falls below N·tol; this makes the
    stopping rule ||Δr||₁ < 10⁻⁸. If NetworkX has not converged after 100 iterations, the iterate after 100
    steps of the same update is used. Both start from r = t̃. `ppr_engine: power` runs that update in SciPy; the test suite checks
    that the two agree.
16. **Evidence pool and MMR.** Up to 24 representative passages (ranked by r) and 24 facts (ranked by mean
    endpoint mass) are candidates. Pruning keeps items greedily by score and skips any item with similarity
    ≥ 0.97 to an item already kept, up to 12.
17. **Prompt truncation.** A prompt above 4,096 tokens keeps its first and last 2,048 tokens.

## Reasoning and gate
18. **Denoiser ranking.** Items are ranked by clipped cosine similarity to q plus the retrieval score
    normalised by its maximum.
    - The parallel branch then drops items with similarity ≥ 0.95 to an item already kept.
    - The chained branch puts first the items that mention a concept of a sub-question, then items sharing
      an entity with them, then the rest.
    - Both keep the top eight.
19. **Chained branch.** The path search starts from the concepts of the first sub-question in π(q) and
    scores a path by the mean clipped cosine similarity of its facts to q. One path-answer call is made
    per step of π(q), and the last step answers q. A one-step chain is answered as (sub-question, q), so a
    chained question makes 2–4 path-answer calls.
20. **NLI aggregation.** A hypothesis (a claim, the candidate answer, a sample or a self fact) is scored
    against each evidence item separately, and the highest entailment is kept. A premise longer than the
    512-token window is split into windows with 50% overlap, and the window with the highest entailment is
    kept.
21. **Conflict-scoring output limits.** The call has 768 new tokens. Atomic claims beyond 384 tokens and
    self facts beyond 384 tokens are discarded, so each field keeps its own limit.
22. **c_param** is the unweighted mean over self facts of rel(self fact, q) × (1 − entailment of the self
    fact by C). Self-fact confidences are recorded but not used as weights. c_param is 0 when there are no
    self facts.
23. **Consistency** is the share of the k samples in the largest cluster of equivalent answers. Two answers
    are equivalent if their normalised strings are equal or each entails the other (≥ 0.5).
24. **Sampling seeds.** Uncertainty sample j of seed s uses seed 1000·s + j; regeneration samples add 500.
25. **Regeneration.**
    - The input is the top six facts of C by retrieval score. If C contains no fact, the answer is withheld.
    - No new conflict-scoring call is made, which keeps the +6 call budget.
    - The claims of the regenerated answer are its sentences, the self facts are reused, the chained
      v_branch keeps the path relevance, and u_faith uses k new samples of the regeneration prompt.
26. **Evidence path.** The returned facts are ranked by how strongly each fact entails the answer (premise =
    fact).
27. **Model abstentions.** An answer that states that the evidence is insufficient is recorded as an
    abstention, in every variant and baseline.
28. **Ablation semantics.**
    - −C2 returns the candidate answer without conflict scoring or sampling.
    - "−regeneration" returns middle-band answers unchanged.
    - "−threshold abstention" sends low-band answers to regeneration and returns the regenerated answer
      whatever its score.
    - Removing c_answer or c_param makes c_conf the remaining term.
    - A dropped signal is also masked in the calibration fit (`fit_calibration.py --drop`).
29. **Router variants.** Oracle, always-parallel and always-chained routing make no classifier call; oracle
    routing requires a gold `route` label. Run-both keeps the branch with the higher branch verification.
30. **Independent family** (Supplementary Table S18, `run_inference.py --verifier independent`). The model
    in `models.independent_verifier` makes the conflict-scoring call (self facts and atomic claims) and
    verifies the claims for v_branch.

## Calibration and evaluation
31. **Calibration target for TempRAG.** Its primary metric, context faithfulness, is not a correctness
    measure, so y is normalised exact correctness against the reference answer. For the other datasets, y
    uses the scorer of the dataset's primary metric (Hits@1 uses the first line; BioASQ yes/no uses the first
    word).
32. **θ_high** is the smallest development score s* for which the records with s ≥ s* reach 85% precision,
    scanning scores in decreasing order. It is never set below θ_low.
33. **Leave-one-dataset-out stress test.** For each held-out dataset, weights and θ_high are fitted on the
    development records of the other four datasets (LODO) or of all five (pooled), then evaluated on all
    test records of the held-out dataset with ten equal-width bins. Because these bins are equal-width,
    not equal-frequency, these ECE values are on a different scale from the per-dataset test ECE.
34. **Resampling.** Comparison i of Table 5 uses seed 20261003 + i, and supplementary comparison i uses
    20261004 + i. The sign-flip P value is (count + 1) / (B + 1).
35. **Claim-level evaluator.** Atomic-claim decomposition, claim support and context relevance are judged
    by `models.evaluator` (Qwen2.5-14B-Instruct) with yes/no prompts at T = 0; it is a separate model from
    the gate's NLI. The offline stand-in uses a separate lexical NLI instance and sentence splitting.
    - The hallucination rate covers every answered test question, including answered evidence-removal
      questions. Their reference evidence is taken from the original corpus (`--reference-corpus`).
    - Reference evidence for hallucination is the gold supporting passages, or the retrieved items when no
      gold support is released.
    - Retrieval recall counts a gold passage as retrieved when the passage, a fact extracted from it, or the
      representative of its merged group is in C.
    - Path recall counts the gold path elements that occur in the retrieved evidence text.
    - The decomposer uses 384 new tokens and the yes/no judges 4 (`evaluation.evaluator`). If the
      decomposition is not a JSON list, the answer's sentences are used as claims.
36. **Thresholded alternatives.** The abstention threshold of SelfCheckGPT, semantic entropy (and of an
    external system with sampled answers, `external_confidence.py`) is frozen at the 10% quantile of the
    system's development confidences, the same budget as θ_low.
    - The semantic-entropy confidence is 1 − H / log k.
    - The SelfCheckGPT confidence is the mean entailment of the answer by the k samples.
37. **Compute-matched self-consistency.** The number of samples is the rounded mean number of model calls
    in the PEAK-RAG test records of the same run (`--match-calls`); it is not a fixed constant.
38. **Evidence-removal subset.**
    - The documents holding a question's gold support are removed from the inference corpus.
    - A question is eligible only if no remaining document contains its reference answer, and the removal
      takes no evidence from another question that stays answerable.
    - The sampling seed is 20261004.

## Values that must be filled in before release
- The full revision hashes of `models.evaluator` and `models.independent_verifier` (the manuscript says
  they are pinned in the configuration files; they are `null` here until copied from the run logs).
- The Zenodo DOI in `CITATION.cff`.
