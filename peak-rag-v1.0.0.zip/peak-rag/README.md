# PEAK-RAG

Code for *Prerequisite-aware retrieval and calibrated abstention for technical question answering,
motivated by mechanical design education* (X. Ma, Scientific Reports, under review).

PEAK-RAG mines candidate prerequisite relations from a corpus, biases graph retrieval towards the mined
prerequisites of the concepts in a question, and fuses three reliability signals into a calibrated score
that accepts, regenerates or withholds each answer. No language model is fine-tuned; only the gate
calibration and three hyperparameters are fitted on development data.

## Layout

| Path | Paper |
|---|---|
| `configs/default.yaml` | every constant of the configuration table, the external-components table and the released calibration |
| `peak_rag/offline/build.py` | Algorithm 1: extraction, candidate conflicts and KeepDropOrMerge, three-layer memory, thematic denoising, indexing graph, structural unification |
| `peak_rag/offline/prereq.py` | prerequisite mining: typed 1.0, co-occurrence 0.5, first-mention 0.3/(j−i), max merge; foundationality |
| `peak_rag/online/retrieval.py` | Algorithm 2: decomposition, reasoning DAG, Kahn sort with foundationality ties, Eq. 1, Eq. 2, dangling-aware PPR, evidence assembly and MMR pruning |
| `peak_rag/online/gate.py` | Algorithm 3: router, task-aware denoiser, parallel and chained branches, v_branch, c_conf, u_faith, Eq. 3, Eq. 4 |
| `peak_rag/online/pipeline.py` | end-to-end workflow, regeneration, call accounting (9 / 11–13 / 15–19 calls) |
| `peak_rag/calibration.py` | Section 3.6: composite correctness target, constrained logistic fit, θ_low and θ_high selection |
| `peak_rag/baselines.py` | shared-configuration references (dense RAG, compute-matched self-consistency) and thresholded SelfCheckGPT / semantic-entropy abstention |
| `peak_rag/runner.py` | running systems, the claim-level evaluator, auxiliary metrics, thresholded alternatives |
| `peak_rag/eval/` | metrics, abstention and risk–coverage, paired bootstrap, sign-flip permutation, Holm, Friedman–Nemenyi, Wilson, κ, McNemar, ECE / Brier / NLL / AUROC, LODO, Table 6 |
| `peak_rag/prompts.py` | prompt templates of Appendix B |
| `scripts/` | command-line entry points (below) |
| `tests/` | configuration-vs-paper checks, statistics checks, unit and end-to-end tests |
| `IMPLEMENTATION_NOTES.md` | choices the manuscript does not specify, and how this code makes them |

## Installation

```bash
conda env create -f environment.yml && conda activate peak-rag
# or: pip install -r requirements.txt   (CPU-only parts: graph, retrieval, calibration, evaluation)
```

The reported results use one NVIDIA A100-80GB, batch size 1, and the model revisions pinned in
`configs/default.yaml`.

## Reproducing the pipeline

```bash
# per corpus (data schema: peak_rag/data.py)
python scripts/make_unanswerable.py --corpus data/MLPQ/corpus.jsonl --questions data/MLPQ/questions.jsonl --out-dir data/MLPQ_eval
python scripts/build_graph.py --corpus data/MLPQ_eval/corpus.jsonl --out runs/MLPQ/kb.pkl --backend hf

# development pass, calibration on the pooled development records of the five datasets
python scripts/run_inference.py --kb runs/MLPQ/kb.pkl --questions data/MLPQ_eval/questions.jsonl --split dev --seeds 17 --out runs/MLPQ/dev.jsonl --backend hf
python scripts/fit_calibration.py --records runs/*/dev.jsonl --out runs/calibration.json

# test pass with five seeds (the claim-level evaluator Qwen2.5-14B-Instruct is loaded with --backend hf)
python scripts/run_inference.py --kb runs/MLPQ/kb.pkl --questions data/MLPQ_eval/questions.jsonl --calibration runs/calibration.json --out runs/MLPQ/peak.jsonl --backend hf
# ablations: inference-time variants (--variant=-C1, -C2, -both, -tiebreak, -teleport, reverse, undirected,
# no-prereq, -v_branch, -c_answer, -c_param, -u_faith, uncalibrated, -regeneration, -threshold-abstention,
# router-oracle, router-parallel, router-chained, router-both, k=1, k=3, k=10) ...
python scripts/run_inference.py ... --variant=-C1 --out runs/MLPQ/peak_-C1.jsonl
# ... grid points through config overrides, e.g. the lambda and alpha grids of Appendix D
python scripts/run_inference.py ... --split dev --set retrieval.lambda_mix=0.1 retrieval.alpha_teleport=0.05 --out ...
# ... and mining-signal variants, which need their own graph
python scripts/build_graph.py --corpus ... --variant=typed-only --out runs/MLPQ/kb_typed.pkl --backend hf
# ... independent-family verification (Supplementary Table S18)
python scripts/run_inference.py ... --verifier independent --out runs/MLPQ/peak_indep.jsonl

# reference systems (run on dev and test, so that the thresholded alternatives can freeze their thresholds)
python scripts/run_inference.py ... --system dense+semantic-entropy --out runs/MLPQ/dense_se.jsonl
python scripts/run_inference.py ... --system self-consistency --match-calls runs/MLPQ/peak.jsonl --out runs/MLPQ/sc.jsonl
python scripts/external_confidence.py --records runs/baselines/parka_samples.jsonl --out runs/baselines/parka_se.jsonl

# tables: Table 4, Table 5, S14, Figure 6, Table 6, abstention, AURC, Figure 9 / S15, S16 LODO, Table 8
python scripts/evaluate.py --records runs/*/*.jsonl runs/baselines/*.jsonl --out runs/tables \
    --threshold-systems dense+selfcheck dense+semantic-entropy PARKA
```

The released calibration (`gating.weights`: w1 = 2.0000, w2 = 2.0000, w3 = 1.4254, b = −3.0288;
θ_low = 0.35, θ_high = 0.70) is used when `--calibration` is not given. Records of the fifteen published
baselines, run from their authors' code, enter `evaluate.py` through the same record schema
(`dataset, qid, system, seed, split, unanswerable, abstained, primary_score`).

## Smoke test without a GPU

```bash
pip install -r requirements.txt
python -m pytest            # 26 tests
bash scripts/run_demo.sh    # toy mechanical-design corpus, every stage and every table
```

`--backend offline` (the default) replaces the generator, embedder and NLI model by deterministic CPU
stand-ins (`peak_rag/backends/offline.py`). They exercise the full code path, including every call site
and the exact number of model calls, but they are not the models of the paper, and toy-corpus outputs
are not results.

## Citation and archive

See `CITATION.cff`. The archived release is on Zenodo (DOI to be added on deposit).
